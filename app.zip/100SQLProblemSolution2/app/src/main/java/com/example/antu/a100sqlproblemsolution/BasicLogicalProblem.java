package com.example.antu.a100sqlproblemsolution;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class BasicLogicalProblem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_logical_problem);
    }
}
