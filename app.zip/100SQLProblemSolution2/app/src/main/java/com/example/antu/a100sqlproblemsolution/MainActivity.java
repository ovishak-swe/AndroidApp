package com.example.antu.a100sqlproblemsolution;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class MainActivity extends AppCompatActivity {

    LinearLayout background;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    Button button9;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        background = (LinearLayout) findViewById(R.id.background);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        button4 = (Button) findViewById(R.id.button4);
        button5 = (Button) findViewById(R.id.button5);
        button6 = (Button) findViewById(R.id.button6);
        button7 = (Button) findViewById(R.id.button7);
        button8 = (Button) findViewById(R.id.button8);
        button9 = (Button) findViewById(R.id.button9);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BasicSelectProblem();
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BasicLogicalProblem();
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BetweenAndSomeOperator();
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringLikeOperation();
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SetOperation();
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Aggregatefunction();
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               SQLJoin();
            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HardQuestion();
            }
        });

    }
    public void  BasicSelectProblem()
    {
        Intent intent = new Intent(this, BasicSelectProblem.class);
        startActivity(intent);
    }

    public void BasicLogicalProblem() {
        Intent intent = new Intent(this, BasicLogicalProblem.class);
        startActivity(intent);
    }

    public void BetweenAndSomeOperator() {
        Intent intent = new Intent(this, BetweenAndSomeOperator.class);
        startActivity(intent);
    }


    public void StringLikeOperation() {
        Intent intent = new Intent(this, StringLikeOperation.class);
        startActivity(intent);
    }

    public void SetOperation() {
        Intent intent = new Intent(this, SetOperation.class);
        startActivity(intent);
    }

    public void Aggregatefunction() {
        Intent intent = new Intent(this, Aggregatefunction.class);
        startActivity(intent);
    }

    public void SQLJoin() {
        Intent intent = new Intent(this, SQLJoin.class);
        startActivity(intent);
    }

    public void HardQuestion() {
        Intent intent = new Intent(this, HardQuestion.class);
        startActivity(intent);
    }


}
