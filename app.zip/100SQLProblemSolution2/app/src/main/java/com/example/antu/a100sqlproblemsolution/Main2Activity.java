package com.example.antu.a100sqlproblemsolution;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    private TextView tv;
    private ImageView iv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        tv= (TextView)findViewById(R.id.textView2);
        Animation anim = AnimationUtils.loadAnimation(this,R.anim.mytransition);
        tv.startAnimation(anim);
        final Intent intent = new Intent(this,MainActivity.class);
        Thread timer = new Thread()
        {
            @Override
            public void run() {
                try {
                     sleep(5000);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }finally {
                          startActivity(intent);
                          finish();
                }

            }
        };timer.start();
    }
}
